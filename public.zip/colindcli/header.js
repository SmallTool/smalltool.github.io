document.writeln("<div style=\'text-align:center;overflow: hidden;\'>");
document.writeln("<ins class=\'adsbygoogle\'");
document.writeln("     style=\'display:inline-block;width:728px;height:90px\'");
document.writeln("     data-ad-client=\'ca-pub-2222513431618339\'");
document.writeln("     data-ad-slot=\'8930471380\'></ins>");
document.writeln("</div>");


(adsbygoogle = window.adsbygoogle || []).push({});