document.writeln("<ins class=\'adsbygoogle\'");
document.writeln("     style=\'display:inline-block;width:336px;height:280px\'");
document.writeln("     data-ad-client=\'ca-pub-2222513431618339\'");
document.writeln("     data-ad-slot=\'2937040181\'></ins>");

(adsbygoogle = window.adsbygoogle || []).push({});