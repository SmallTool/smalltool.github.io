document.writeln("<ins class=\'adsbygoogle\'");
document.writeln("     style=\'display:inline-block;width:200px;height:200px\'");
document.writeln("     data-ad-client=\'ca-pub-2222513431618339\'");
document.writeln("     data-ad-slot=\'1320706181\'></ins>");

(adsbygoogle = window.adsbygoogle || []).push({});