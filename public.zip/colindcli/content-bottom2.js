document.writeln("<ins class=\'adsbygoogle\'");
document.writeln("     style=\'display:block; text-align:center;\'");
document.writeln("     data-ad-layout=\'in-article\'");
document.writeln("     data-ad-format=\'fluid\'");
document.writeln("     data-ad-client=\'ca-pub-2222513431618339\'");
document.writeln("     data-ad-slot=\'3725516153\'></ins>");

(adsbygoogle = window.adsbygoogle || []).push({});