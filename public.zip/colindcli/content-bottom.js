
document.writeln("<ins class=\'adsbygoogle\'");
document.writeln("     style=\'display:inline-block;width:320px;height:100px\'");
document.writeln("     data-ad-client=\'ca-pub-2222513431618339\'");
document.writeln("     data-ad-slot=\'4413773382\'></ins>");

(adsbygoogle = window.adsbygoogle || []).push({});